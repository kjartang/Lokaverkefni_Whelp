<?php

if (isset($_POST['Utskra'])) {
	header("location: ../FrontPage.php");
}

?>