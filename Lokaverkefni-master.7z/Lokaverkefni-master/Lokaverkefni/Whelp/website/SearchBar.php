<?php 
$servername = "tsuts.tskoli.is";
$dbname = "0704973019_whelp";
$username = "0704973019";
$password = "mypassword";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

    $result = $conn->query("SELECT * from counties");
    
    echo "<html>";
    echo "<body>";
    echo "<select name='id'>";

    while ($row = $result->fetch_assoc()) {

                  unset($all_counties);
                  $all_counties = $row['counties'];
                  echo '<option value="'.$all_counties.'"></option>';
                 
}

    echo "</select>";
    echo "</body>";
    echo "</html>";

?>